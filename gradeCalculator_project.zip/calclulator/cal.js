 // Takes user input (marks for five subjects)
        var a =parseInt(prompt("Enter the marks of Tamil"));
        var b =parseInt(prompt("Enter the marks of English"));
        var c =parseInt(prompt("Enter the marks of Maths"));
        var d =parseInt(prompt("Enter the marks of Science"));
        var e =parseInt(prompt("Enter the marks of Socialscience"));
        //Calculates the total marks
        var total=a+b+c+d+e;
        //Computes the average marks.
        var average=total/5;

          